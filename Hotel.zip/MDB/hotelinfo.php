<?php 
session_start();
 ?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>HotelInfo</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="css/mdb.min.css" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="css/style.css" rel="stylesheet">
</head>

<body>

  <!-- Start your project here-->
 <nav class="navbar navbar-expand-lg navbar-dark deep-purple">
  <a class="navbar-brand" href="index.php">Hotel Fern</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav"
    aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="gallery.php">Gallery</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="restaurant.php">Restaurant</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="hotelinfo.php">Hotel Info</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="resinfo.php">Restro Info</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="contact.php">Contact Us</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="form.php">Room Booking</a>
      </li>
      <?php if (!empty($_SESSION["name"])) { ?>
        <li class="nav-item">
        <a class="nav-link" href="category.php">Categories</a>
      </li>
        <li class="nav-item">
        <a class="nav-link" href="resinfo.php"><?php echo $_SESSION["name"];?></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="logout.php">Logout</a>
      </li>
  <?php } 
  else {?>
    
    <li class="nav-item">
      
        <a class="nav-link" href="logsign.php">Log In/Sign Up</a>
      </li>
  <?php } ?>
    </ul>
  </div>
</nav>
<div style="margin-top: 20px;">
<div class="container" style="font-family: cursive; ">
  <h1 align="center">Hotel Description</h1>
 <p style="font-size: 20px;">The <strong>Hotel Fern</strong> is the right choice for visitors who are searching for a combination of charm, peace and quiet, and a convenient position from which to explore <strong>Jaipur</strong>. It is a small, comfortable hotel, situated on the <strong>banks of River Dravyavati. </strong>The Fern family and their staff offer an attentive, personalized service and are always available to offer any help to guests.<br />The hotel is arranged on three floors, without a lift. On the ground floor, apart from the <strong>reception</strong>, there is a comfortable lounge where you can sit and drink tea, or just read. There is also a splendid <strong>terrace, </strong>where, you can relax and immerge yourself from morning onwards in the atmosphere of Venetian daily life, watching the city travelling about by water and people gathering together and filling the alleyways and little squares with their chatter.<br />The rooms are arranged on the first, second and third floors. On the top floor, there is also a delightful terrace or <strong>solarium</strong> available for the use of guests, from where you can enjoy the wonderful view.<br />The buffet breakfast is served in the lounge on the ground floor, and also outside on our little patio during the summer months.<br />The hotel provides an internet point, and a <strong>Wi-Fi</strong> service.</p>
<table class=" alignleft" style="height: 273px; max-width: 600px; text-align: left;" width="100%">
<tbody>
<tr>
<td>
<p><span style="font-size: 14pt;"><strong>Services and Facilities</strong></span></p>
<ul>
<li>24 hour reception</li>
<li>Internet point</li>
<li>Wi-fi</li>
<li>Fax service</li>
<li>Tourist information</li>
<li>Bookings for trips</li>
<li>Bookings for guided tours</li>
<li>Bookings for shows and museums</li>
<li>Concierge</li>
</ul>
</td>
<td>
<p>&nbsp;</p>
<ul>
<li>Night concierge</li>
<li>Left luggage</li>
<li>Ironing service</li>
<li>Hall</li>
<li>Terrace</li>
<li>Bar</li>
<li>Breakfast</li>
<li>Gluten free breakfast available</li>
</ul>
</td>
</tr>
</tbody>
</table>
</div>
</div>
<!-- Footer -->
<footer class="page-footer font-small unique-color-dark">

    <div style="background-color: #6351ce;">
      <div class="container">

        <!-- Grid row-->
        <div class="row py-4 d-flex align-items-center">

          <!-- Grid column -->
          <div class="col-md-6 col-lg-5 text-center text-md-left mb-4 mb-md-0">
            <h6 class="mb-0">Get connected with us on social networks!</h6>
          </div>
          <!-- Grid column -->

          <!-- Grid column -->
          <div class="col-md-6 col-lg-7 text-center text-md-right">

            <!-- Facebook -->
            <a class="fb-ic" href="https://www.facebook.com/">
              <i class="fa fa-facebook white-text mr-4"> </i>
            </a>
            <!-- Twitter -->
            <a class="tw-ic" href="https://www.twitter.com/">
              <i class="fa fa-twitter white-text mr-4"> </i>
            </a>
            <!-- Google +-->
            <a class="gplus-ic" href="https://www.googleplus.com/">
              <i class="fa fa-google-plus white-text mr-4"> </i>
            </a>
            <!--Linkedin -->
            <a class="li-ic" href="https://www.linkedin.com/">
              <i class="fa fa-linkedin white-text mr-4"> </i>
            </a>
            <!--Instagram-->
            <a class="ins-ic" href="https://www.instagram.com/">
              <i class="fa fa-instagram white-text"> </i>
            </a>
          </div>
          <!-- Grid column -->

        </div>
        <!-- Grid row-->

      </div>
    </div>

    <!-- Footer Links -->
    <div class="container text-center text-md-left mt-5">

      <!-- Grid row -->
      <div class="row mt-3">

        <!-- Grid column -->
        <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">

          <!-- Content -->
          <h6 class="text-uppercase font-weight-bold">Hotel Fern</h6>
          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
          <p>Here you can use rows and columns here to organize your footer content. Lorem ipsum dolor sit amet, consectetur
            adipisicing elit.</p>

        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">

          <!-- Links -->
          <h6 class="text-uppercase font-weight-bold">Products</h6>
          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
          <p>
            <a href="index.php">Hotel Services</a>
          </p>
          <p>
            <a href="form.php">Room Services</a>
          </p>
          <p>
            <a href="restaurant.php">Restaurant</a>
          </p>
          <p>
            <a href="contact.php">Queries</a>
          </p>

        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">

          <!-- Links -->
          <h6 class="text-uppercase font-weight-bold">Useful links</h6>
          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
          <p>
            <a href="index.php">Facilities</a>
          </p>
          <p>
            <a href="form.php">Become a Guest</a>
          </p>
          <p>
            <a href="category.php">Rates</a>
          </p>
          <p>
            <a href="contact.php">Help</a>
          </p>
        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">

          <!-- Links -->
          <h6 class="text-uppercase font-weight-bold">Contact</h6>
          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
          <p>
            <i class="fa fa-home mr-3"></i> JAIPUR ,302022</p>
          <p>
            <i class="fa fa-envelope mr-3"></i> 2017pietcsnikhil073@poornima.org</p>
          <p>
            <i class="fa fa-envelope mr-3"></i> 2017pietcsmridul065@poornima.org</p>
          <p>
            <i class="fa fa-phone mr-3"></i> +91 7665-773-365</p>
          <p>
            <i class="fa fa-print mr-3"></i> +91 7073-910-522</p>

        </div>
        <!-- Grid column -->

      </div>
      <!-- Grid row -->

    </div>
    <!-- Footer Links -->

    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">© 2018 Copyright: MEcrew :)
      
    </div>
    <!-- Copyright -->

  </footer>  <!-- Footer -->
  <!-- /Start your project here-->

  <!-- SCRIPTS -->
  <!-- JQuery -->
  <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.min.js"></script>
</body>

</html>