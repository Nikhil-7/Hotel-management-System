<?php 
session_start();
 ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Home</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="css/mdb.min.css" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="css/style.css" rel="stylesheet">
</head>
<body>

  <!-- Start your project here-->
 <nav class="navbar navbar-expand-lg navbar-dark deep-purple">
  <a class="navbar-brand" href="index.php">Hotel Fern</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav"
    aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="gallery.php">Gallery</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="restaurant.php">Restaurant</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="hotelinfo.php">Hotel Info</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="resinfo.php">Restro Info</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="contact.php">Contact Us</a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="form.php">Room Booking</a>
      </li>
      <?php if (!empty($_SESSION["name"])) { ?>
      	<li class="nav-item">
        <a class="nav-link" href="category.php">Categories</a>
      </li>
      <?php if ($_SESSION["type"]=='admin') { ?>
      <li class="nav-item">
        <a class="nav-link" href="admin.php">Admin</a>
      </li>
        <?php } ?>
      	<li class="nav-item">
        <a class="nav-link" href="#"><?php echo $_SESSION["name"];?></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="logout.php">Logout</a>
      </li>
  <?php } 
  else {?>
  	
  	<li class="nav-item">
  		
        <a class="nav-link" href="logsign.php">Log In/Sign Up</a>
      </li>
  <?php } ?>
    </ul>
  </div>
</nav>

<!--Carousel Wrapper-->
<div id="carousel-thumb" class="carousel slide carousel-fade carousel-thumbnails" data-ride="carousel">
  <!--Slides-->
  <div class="carousel-inner" role="listbox"  style="height: 800px; margin-top:25px;">
    <div class="carousel-item active">
      <img src="5.jpg" style="width: 100%; height: 100%;" alt="First slide">
    </div>
    <div class="carousel-item">
      <img  src="4.jpg" style="width: 100%; height: 100%; " alt="Second slide">
    </div>
    <div class="carousel-item">
      <img  src="7.jpg"  style="width: 100%; height: 100%; " alt="Third slide">
    </div>
  </div>
  <!--/.Slides-->
  <!--Controls-->
  <a class="carousel-control-prev" href="#carousel-thumb" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carousel-thumb" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
  <!--/.Controls-->
  <ol class="carousel-indicators">
    <li data-target="#carousel-thumb" data-slide-to="0" class="active"> <img class="d-block w-100" src="5.jpg"
        class="img-fluid"></li>
    <li data-target="#carousel-thumb" data-slide-to="1"><img class="d-block w-100" src="4.jpg"
        class="img-fluid"></li>
    <li data-target="#carousel-thumb" data-slide-to="2"><img class="d-block w-100" src="7.jpg"
        class="img-fluid"></li>
  </ol>
</div>
<!--/.Carousel Wrapper-->

<div class="">
	<div class="row container " style="margin:30px ;margin-left: 200px;margin-right: 200px;" >
		<div class="col-md-4">
				<!-- Card -->
<div class="card card-image" style="background-image: url(5.jpg);">

  <!-- Content -->
  <div class="text-white text-center d-flex align-items-center rgba-black-strong py-5 px-4">
    <div>
      <h5 class="pink-text"><i class="fa fa-pie-chart"></i>Hotel</h5>
      <h3 class="card-title pt-2"><strong>This is Hotel Booking Page</strong></h3>
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellat fugiat, laboriosam, voluptatem,
        optio vero odio nam sit officia accusamus minus error nisi architecto nulla ipsum dignissimos.
        Odit sed qui, dolorum!.</p>
      <a class="btn btn-pink" href="form.php"><i class="fa fa-clone left"></i> View project</a>
    </div>
  </div>

</div>
<!-- Card -->
		</div>

		<div class="col-md-4">
				<!-- Card -->
<div class="card card-image" style="background-image: url(8.jpg);">

  <!-- Content -->
  <div class="text-white text-center d-flex align-items-center rgba-black-strong py-5 px-4">
    <div>
      <h5 class="pink-text"><i class="fa fa-pie-chart">Hotel Info</i></h5>
      <h3 class="card-title pt-2"><strong>This is Hotel Information</strong></h3>
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellat fugiat, laboriosam, voluptatem,
        optio vero odio nam sit officia accusamus minus error nisi architecto nulla ipsum dignissimos.
        Odit sed qui, dolorum!.</p>
      <a class="btn btn-pink" href="hotelinfo.php"><i class="fa fa-clone left"></i> View project</a>
    </div>
  </div>

</div>
<!-- Card -->
		</div>

		<div class="col-md-4">
				<!-- Card -->
<div class="card card-image" style="background-image: url(6.jpg);">

  <!-- Content -->
  <div class="text-white text-center d-flex align-items-center rgba-black-strong py-5 px-4">
    <div>
      <h5 class="pink-text"><i class="fa fa-pie-chart">Restaurant Info</i> </h5>
      <h3 class="card-title pt-2"><strong>This is Restaurant Info page</strong></h3>
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellat fugiat, laboriosam, voluptatem,
        optio vero odio nam sit officia accusamus minus error nisi architecto nulla ipsum dignissimos.
        Odit sed qui, dolorum!.</p>
      <a class="btn btn-pink" href="restaurantinfo.php"><i class="fa fa-clone left"></i> View project</a>
    </div>
  </div>

</div>
<!-- Card -->
		</div>

	</div>


<div class="">
	<div class="row container " style="margin:20px auto 65px;margin-left: 200px;margin-right: 200px;">
		<div class="col-md-4">
				<!-- Card -->
<div class="card card-image" style="background-image: url(3.jpg);">

  <!-- Content -->
  <div class="text-white text-center d-flex align-items-center rgba-black-strong py-5 px-4">
    <div>
      <h5 class="pink-text"><i class="fa fa-pie-chart"></i>Restaurant</h5>
      <h3 class="card-title pt-2"><strong>This is Restaurant Page</strong></h3>
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellat fugiat, laboriosam, voluptatem,
        optio vero odio nam sit officia accusamus minus error nisi architecto nulla ipsum dignissimos.
        Odit sed qui, dolorum!.</p>
      <a class="btn btn-pink" href="restaurant.php"><i class="fa fa-clone left"></i> View project</a>
    </div>
  </div>

</div>
<!-- Card -->
		</div>

		<div class="col-md-4">
				<!-- Card -->
<div class="card card-image" style="background-image: url(5.jpg);">

  <!-- Content -->
  <div class="text-white text-center d-flex align-items-center rgba-black-strong py-5 px-4">
    <div>
      <h5 class="pink-text"><i class="fa fa-pie-chart"></i> Gallery</h5>
      <h3 class="card-title pt-2"><strong>This is Hotel Gallery Page</strong></h3>
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellat fugiat, laboriosam, voluptatem,
        optio vero odio nam sit officia accusamus minus error nisi architecto nulla ipsum dignissimos.
        Odit sed qui, dolorum!.</p>
      <a class="btn btn-pink" href="gallery.php"><i class="fa fa-clone left"></i> View project</a>
    </div>
  </div>

</div>
<!-- Card -->
		</div>

		<div class="col-md-4">
				<!-- Card -->
<div class="card card-image" style="background-image: url(8.jpg);">

  <!-- Content -->
  <div class="text-white text-center d-flex align-items-center rgba-black-strong py-5 px-4">
    <div>
      <h5 class="pink-text"><i class="fa fa-pie-chart"></i> Contact Us</h5>
      <h3 class="card-title pt-2"><strong>This is Contact Us page</strong></h3>
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellat fugiat, laboriosam, voluptatem,
        optio vero odio nam sit officia accusamus minus error nisi architecto nulla ipsum dignissimos.
        Odit sed qui, dolorum!.</p>
      <a class="btn btn-pink" href="contact.php"><i class="fa fa-clone left"></i> View project</a>
    </div>
  </div>

</div>
<!-- Card -->
		</div>

	</div>

<!-- Footer -->
<footer class="page-footer font-small unique-color-dark">

    <div style="background-color: #6351ce;">
      <div class="container">

        <!-- Grid row-->
        <div class="row py-4 d-flex align-items-center">

          <!-- Grid column -->
          <div class="col-md-6 col-lg-5 text-center text-md-left mb-4 mb-md-0">
            <h6 class="mb-0">Get connected with us on social networks!</h6>
          </div>
          <!-- Grid column -->

          <!-- Grid column -->
          <div class="col-md-6 col-lg-7 text-center text-md-right">

            <!-- Facebook -->
            <a class="fb-ic" href="https://www.facebook.com/">
              <i class="fa fa-facebook white-text mr-4"> </i>
            </a>
            <!-- Twitter -->
            <a class="tw-ic" href="https://www.twitter.com/">
              <i class="fa fa-twitter white-text mr-4"> </i>
            </a>
            <!-- Google +-->
            <a class="gplus-ic" href="https://www.googleplus.com/">
              <i class="fa fa-google-plus white-text mr-4"> </i>
            </a>
            <!--Linkedin -->
            <a class="li-ic" href="https://www.linkedin.com/">
              <i class="fa fa-linkedin white-text mr-4"> </i>
            </a>
            <!--Instagram-->
            <a class="ins-ic" href="https://www.instagram.com/">
              <i class="fa fa-instagram white-text"> </i>
            </a>

          </div>
          <!-- Grid column -->

        </div>
        <!-- Grid row-->

      </div>
    </div>

    <!-- Footer Links -->
    <div class="container text-center text-md-left mt-5">

      <!-- Grid row -->
      <div class="row mt-3">

        <!-- Grid column -->
        <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">

          <!-- Content -->
          <h6 class="text-uppercase font-weight-bold">Hotel Fern</h6>
          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
          <p>Here you can use rows and columns here to organize your footer content. Lorem ipsum dolor sit amet, consectetur
            adipisicing elit.</p>

        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">

          <!-- Links -->
          <h6 class="text-uppercase font-weight-bold">Products</h6>
          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
          <p>
            <a href="restaurant.php">Restaurant Services</a>
          </p>
          <p>
            <a href="form.php">Room Services</a>
          </p>
          <p>
            <a href="gallery.php">Gallery</a>
          </p>
          <p>
            <a href="contact.php">Contact Us</a>
          </p>

        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">

          <!-- Links -->
          <h6 class="text-uppercase font-weight-bold">Useful links</h6>
          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
          <p>
            <a href="restaurant.php">Facilities</a>
          </p>
          <p>
            <a href="contact.php">Become a Guest</a>
          </p>
          <p>
            <a href="contact.php">Rates</a>
          </p>
          <p>
            <a href="contact.php">Help</a>
          </p>

        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">

          <!-- Links -->
          <h6 class="text-uppercase font-weight-bold">Contact</h6>
          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
          <p>
            <i class="fa fa-home mr-3"></i> JAIPUR ,302022</p>
          <p>
            <i class="fa fa-envelope mr-3"></i> 2017pietcsnikhil073@poornima.org</p>
          <p>
          	<i class="fa fa-envelope mr-3"></i> 2017pietcsmridul065@poornima.org</p>
          <p>
            <i class="fa fa-phone mr-3"></i> +91 7665-773-365</p>
          <p>
            <i class="fa fa-print mr-3"></i> +91 7073-910-522</p>

        </div>
        <!-- Grid column -->

      </div>
      <!-- Grid row -->

    </div>
    <!-- Footer Links -->

    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">© 2018 Copyright: MEcrew :)
      
    </div>
    <!-- Copyright -->

  </footer>
  <!-- Footer -->
  <!-- /Start your project here-->

  <!-- SCRIPTS -->
  <!-- JQuery -->
  <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.min.js"></script>
</body>

</html>
