<?php 
$a=$_POST['t1'];
$b=$_POST['t2'];
$c=$_POST['t3'];
$d=$_POST['t4'];
$e=$_POST['t5'];
$f=$_POST['t6'];
$g=$_POST['t7'];
$h=$_POST['t8'];
$i=$_POST['t9'];

$server='localhost';
$username='root';
$password='';
$dbname='hotel';

$connect=mysqli_connect($server,$username,$password,$dbname);
if($connect)
{
    $sql="select noroom from room_catg where room_type='$h'";
    if($result=mysqli_query($connect,$sql))
    {
      $row=mysqli_fetch_assoc($result);
      if($row["noroom"])
      {
      $sql2="INSERT INTO `room`(`name`, `email`, `mob_no`, `DOB`, `member`, `check_in_date`, `check_out_date`, `room categories`, `file`) VALUES ('$a','$b','$c','$d','$e','$f','$g','$h','$i')";
      $sql3="update room_catg set noroom = noroom-1 where room_type='$h'&& noroom>0";
      if (mysqli_query($connect,$sql2)&&mysqli_query($connect,$sql3))
        echo "<script>alert('data insert');window.location.assign('index.php')</script>";
    }
    else
         echo "<script>alert('No Room Available in this Category');window.location.assign('form.php')</script>";
  }
  else 
  {
       echo "<script>alert('data not insert plz try again');window.location.assign('form.php')</script>";    	
    }  
   }
 ?>