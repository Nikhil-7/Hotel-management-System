<?php 
session_start();
 ?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>ResInfo</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="css/mdb.min.css" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="css/style.css" rel="stylesheet">
</head>

<body>

  <!-- Start your project here-->
 <nav class="navbar navbar-expand-lg navbar-dark deep-purple">
  <a class="navbar-brand" href="index.php">Hotel Fern</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav"
    aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="gallery.php">Gallery</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="restaurant.php">Restaurant</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="hotelinfo.php">Hotel Info</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="resinfo.php">Restro Info</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="contact.php">Contact Us</a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="form.php">Room Booking</a>
      </li>
      <?php if (!empty($_SESSION["name"])) { ?>
        <li class="nav-item">
        <a class="nav-link" href="category.php">Categories</a>
      </li>
        <li class="nav-item">
        <a class="nav-link" href="resinfo.php"><?php echo $_SESSION["name"];?></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="logout.php">Logout</a>
      </li>
  <?php } 
  else {?>
    
    <li class="nav-item">
      
        <a class="nav-link" href="logsign.php">Log In/Sign Up</a>
      </li>
  <?php } ?></ul>
    </div>
</nav>
<div class="container" style="margin-top: 30px; margin-bottom: 30px;">
<h1 align="center"><strong>FOOD WITH A CONSCIENCE</strong></h1><br>
<p style="font-size: 20px;font-family: cursive;">We give a great deal of thought to the farmers who grow, raise, and harvest our food, as well as the people who eat it. We seek out family farmers and support purveyors who employ responsible farming methods. This includes farms that value and support conservation, biodiversity, animal stewardship, economic viability, and fair treatment of workers. Above all, we focus on quality, whether we’re bringing in peaches from down the road or broccoli from across the country.</p>

<h2 align="center"><strong>A GREEN FOUNDATION</strong></h2><br>
<p style="font-size: 20px;font-family: cursive;">Our flagship location opened as Jaipur’s first LEED Gold Certified restaurant and as the first upscale-casual, full-service LEED Gold restaurant in the country. These prestigious certifications, offered by the U.S. Green Building Council, recognize architecture and interiors that have been constructed and created with a minimal impact on the environment. Every element is thoughtfully designed, from the efficient HVAC and lighting systems all the way down to the tables made from reclaimed wood. In addition, we continually work to establish and pursue all of our Founding Farmers locations as 3 and 4 Star Certified Green Restaurants®. To make this possible and continue our commitment to being a green business, we compost food waste, use no bottled water on site, donate our used grease so it can be recycled into biofuel, use the most energy efficient equipment, and use occupancy sensors to reduce energy usage.</p>

<h3 align="center"><br><strong>MAINTAINING OUR BELIEFS</strong></h3><br>
<p style="font-size: 20px;font-family: cursive;">We hold ourselves accountable for living our green mission each and every day in our stores, but so does the Green Restaurant Association.  The GRA measures, among many things, recycling practices and high-efficiency water and energy usage.  Every two years we undergo a careful recertification and reevaluation process where the GRA reviews invoices and systems, and scores on a strict point system.  We keep a close eye on maintaining and improving our score as we evolve and new green initiatives become available.</p>
</div>

<!-- Footer -->
<footer class="page-footer font-small unique-color-dark">

    <div style="background-color: #6351ce;">
      <div class="container">

        <!-- Grid row-->
        <div class="row py-4 d-flex align-items-center">

          <!-- Grid column -->
          <div class="col-md-6 col-lg-5 text-center text-md-left mb-4 mb-md-0">
            <h6 class="mb-0">Get connected with us on social networks!</h6>
          </div>
          <!-- Grid column -->

          <!-- Grid column -->
          <div class="col-md-6 col-lg-7 text-center text-md-right">

            <!-- Facebook -->
            <a class="fb-ic" href="https://www.facebook.com/">
              <i class="fa fa-facebook white-text mr-4"> </i>
            </a>
            <!-- Twitter -->
            <a class="tw-ic" href="https://www.twitter.com/">
              <i class="fa fa-twitter white-text mr-4"> </i>
            </a>
            <!-- Google +-->
            <a class="gplus-ic" href="https://www.googleplus.com/">
              <i class="fa fa-google-plus white-text mr-4"> </i>
            </a>
            <!--Linkedin -->
            <a class="li-ic" href="https://www.linkedin.com/">
              <i class="fa fa-linkedin white-text mr-4"> </i>
            </a>
            <!--Instagram-->
            <a class="ins-ic" href="https://www.instagram.com/">
              <i class="fa fa-instagram white-text"> </i>
            </a>

          </div>
          <!-- Grid column -->

        </div>
        <!-- Grid row-->

      </div>
    </div>

    <!-- Footer Links -->
    <div class="container text-center text-md-left mt-5">

      <!-- Grid row -->
      <div class="row mt-3">

        <!-- Grid column -->
        <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">

          <!-- Content -->
          <h6 class="text-uppercase font-weight-bold">Hotel name</h6>
          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
          <p>Here you can use rows and columns here to organize your footer content. Lorem ipsum dolor sit amet, consectetur
            adipisicing elit.</p>

        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">

          <!-- Links -->
          <h6 class="text-uppercase font-weight-bold">Products</h6>
          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
          <p>
            <a href="index.php">Hotel Services</a>
          </p>
          <p>
            <a href="form.php">Room Services</a>
          </p>
          <p>
            <a href="restaurant.php">Restaurant</a>
          </p>
          <p>
            <a href="contact.php">Queries</a>
          </p>

        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">

          <!-- Links -->
          <h6 class="text-uppercase font-weight-bold">Useful links</h6>
          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
          <p>
            <a href="index.php">Facilities</a>
          </p>
          <p>
            <a href="form.php">Become a Guest</a>
          </p>
          <p>
            <a href="category.php">Rates</a>
          </p>
          <p>
            <a href="contact.php">Help</a>
          </p>

        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">

          <!-- Links -->
          <h6 class="text-uppercase font-weight-bold">Contact</h6>
          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
          <p>
            <i class="fa fa-home mr-3"></i> JAIPUR ,302022</p>
          <p>
            <i class="fa fa-envelope mr-3"></i> 2017pietcsnikhil073@poornima.org</p>
          <p>
            <i class="fa fa-envelope mr-3"></i> 2017pietcsmridul065@poornima.org</p>
          <p>
            <i class="fa fa-phone mr-3"></i> +91 7665-773-365</p>
          <p>
            <i class="fa fa-print mr-3"></i> +91 7073-910-522</p>

        </div>
        <!-- Grid column -->

      </div>
      <!-- Grid row -->

    </div>
    <!-- Footer Links -->

    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">© 2018 Copyright:MEcrew :)
      
    </div>
    <!-- Copyright -->

  </footer>
  <!-- Footer -->
  <!-- /Start your project here-->

  <!-- SCRIPTS -->
  <!-- JQuery -->
  <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.min.js"></script>
</body>

</html>