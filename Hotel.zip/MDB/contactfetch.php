<?php 
session_start();
$name=$_POST['uname'];
$email=$_POST['uemail'];
$sub=$_POST['sub'];
$desc=$_POST['desc'];
$server='localhost';
$username='root';

$password='';
$dbname='hotel';
$conn=mysqli_connect($server,$username,$password,$dbname);

$sql="INSERT INTO `contact`(`name`, `email`, `subject`, `description`) VALUES ('$name','$email','$sub','$desc')";
if (mysqli_query($conn,$sql))
  {
  	echo "<script>alert('Data Inserted') 
  	window.location.assign('index.php')
  	</script>";

  }
  ?>