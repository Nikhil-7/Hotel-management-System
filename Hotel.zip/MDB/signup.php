<?php 
session_start();
$name=$_POST['uname'];
$email=$_POST['uemail'];
$mob=$_POST['umob'];
$pass=$_POST['upass'];
$server='localhost';
$username='root';

$password='';
$dbname='hotel';
$conn=mysqli_connect($server,$username,$password,$dbname);

$sql="INSERT INTO `user`(`name`, `email`, `mob_number`, `password`) VALUES ('$name','$email','$mob','$pass')";
if (mysqli_query($conn,$sql))
 {
	$_SESSION["name"]=$name;
	$_SESSION["email"]=$email;
	$_SESSION["type"]="client";
	$_SESSION["mob"]=$mob;
	echo "<script>window.location.assign('index.php')</script>";

$mobile=$_POST['umob'];
$message="Thank you..".$name."..for your valuable time for registering with us. We hope you have a very exquisite experience with us and also expect you to have a very fabulous day.";
$json = json_decode(file_get_contents("https://smsapi.engineeringtgr.com/send/?Mobile=7073910522&Password=nikhil123&Message=".urlencode($message)."&To=".urlencode($mobile)."&Key=npngr2NePRJqZAfCidG6hWM") ,true);
if ($json["status"]==="success") {
    echo $json["msg"];
    //your code when send success
}else{
    echo $json["msg"];
    //your code when not send
}
}
else
{
	echo "not insert";
}

 ?>