<?php 
session_start();
 ?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Contact</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="css/mdb.min.css" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="css/style.css" rel="stylesheet">
</head>

<body>

  <!-- Start your project here-->
  <nav class="navbar navbar-expand-lg navbar-dark deep-purple">
  <a class="navbar-brand" href="index.php">Hotel Fern</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav"
    aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="gallery.php">Gallery</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="restaurant.php">Restaurant</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="hotelinfo.php">Hotel Info</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="resinfo.php">Restro Info</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="contact.php">Contact Us</a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="form.php">Room Booking</a>
      </li>
      <?php if (!empty($_SESSION["name"])) { ?>
        <li class="nav-item">
        <a class="nav-link" href="category.php">Categories</a>
      </li>
        <li class="nav-item">
        <a class="nav-link" href="resinfo.php"><?php echo $_SESSION["name"];?></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="logout.php">Logout</a>
      </li>
  <?php } 
  else {?>
    
    <li class="nav-item">
      
        <a class="nav-link" href="logsign.php">Log In/Sign Up</a>
      </li>
  <?php } ?>
    </ul>
  </div>
</nav>

<div class="container">

<!--Section: Contact v.1-->
<section class="section pb-5">

  <!--Section heading-->
  <h2 class="section-heading h1 pt-4">Contact us</h2>
  <!--Section description-->
  <p class="section-description pb-4">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fugit, error
    amet numquam iure provident voluptate esse quasi, veritatis totam voluptas nostrum quisquam eum porro a
    pariatur accusamus veniam.</p>

  <div class="row">

    <!--Grid column-->
    <div class="col-lg-5 mb-4">

      <!--Form with header-->
      <div class="card">

        <div class="card-body">
          <!--Header-->
          <div >
            <h3><i class="fa fa-envelope"></i> Write to us:</h3>
          </div>

          <p>We'll write rarely, but only the best content.</p>
          <br>
        <form action="contactfetch.php" method="post"> 
          <!--Body-->
          <div class="md-form">
            <i class="fa fa-user prefix grey-text"></i>
            <input type="text" id="form-name" name="uname"  required="" class="form-control">
            <label for="form-name">Your name</label>
          </div>

          <div class="md-form">
            <i class="fa fa-envelope prefix grey-text"></i>
            <input type="email" id="form-email" name="uemail" required="" class="form-control">
            <label for="form-email">Your email</label>
          </div>

          <div class="md-form">
            <i class="fa fa-tag prefix grey-text"></i>
            <input type="text" id="form-Subject" name="sub" required="" class="form-control">
            <label for="form-Subject">Subject</label>
          </div>

          <div class="md-form">
            <i class="fa fa-pencil prefix grey-text"></i>
            <textarea type="text" id="form-text" name="desc" required="" class="form-control md-textarea" rows="3"></textarea>
            <label for="form-text">Description</label>
          </div>

          <div class="text-center mt-4">
            <button class="btn btn-light-blue">Submit</button>
          </div>
</form>
        </div>

      </div>
      <!--Form with header-->

    </div>
    <!--Grid column-->

    <!--Grid column-->
    <div class="col-lg-7">

      <!--Google map-->
      <div id="map-container-7" class="z-depth-1-half map-container" style="height: 450px;width: 600px;"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3562.2426231424365!2d75.84849331499477!3d26.7685349831899!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396dc91e898380fd%3A0xeee859ae1f1b64b0!2sPoornima+Institute+of+Engineering+and+Technology!5e0!3m2!1sen!2sin!4v1540914987259" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen></iframe></div>

      <br>
      <!--Buttons-->
      <div class="row text-center">
        <div class="col-md-4">
          <a ><i class="fa fa-map-marker"></i></a>
          <p>Jaipur, Rajasthan 302022</p>
          <p>India</p>
        </div>

        <div class="col-md-4">
          <a ><i class="fa fa-phone"></i></a>
          <p>70 739 10 522</p>
          <p>76 657 73 365</p>
          <p><b>  24x7 Service </p></b>
        </div>

        <div class="col-md-4">
          <a ><i class="fa fa-envelope"></i></a>
          <p>2107pietcsnikhil073@poornima.org</p>
          <p>2017pietcsmridul065@poornim.org</p>
        </div>
      </div>

    </div>
    <!--Grid column-->

  </div>

</section>
<!--Section: Contact v.1-->

<!--Google Maps-->

</div>

<!-- Footer -->
<footer class="page-footer font-small unique-color-dark">

    <div style="background-color: #6351ce;">
      <div class="container">

        <!-- Grid row-->
        <div class="row py-4 d-flex align-items-center">

          <!-- Grid column -->
          <div class="col-md-6 col-lg-5 text-center text-md-left mb-4 mb-md-0">
            <h6 class="mb-0">Get connected with us on social networks!</h6>
          </div>
          <!-- Grid column -->

          <!-- Grid column -->
          <div class="col-md-6 col-lg-7 text-center text-md-right">

            <!-- Facebook -->
            <a class="fb-ic" href="https://www.facebook.com/">
              <i class="fa fa-facebook white-text mr-4"> </i>
            </a>
            <!-- Twitter -->
            <a class="tw-ic" href="https://www.twitter.com/">
              <i class="fa fa-twitter white-text mr-4"> </i>
            </a>
            <!-- Google +-->
            <a class="gplus-ic" href="https://www.googleplus.com/">
              <i class="fa fa-google-plus white-text mr-4"> </i>
            </a>
            <!--Linkedin -->
            <a class="li-ic" href="https://www.linkedin.com/">
              <i class="fa fa-linkedin white-text mr-4"> </i>
            </a>
            <!--Instagram-->
            <a class="ins-ic" href="https://www.instagram.com/">
              <i class="fa fa-instagram white-text"> </i>
            </a>

          </div>
          <!-- Grid column -->

        </div>
        <!-- Grid row-->

      </div>
    </div>

    <!-- Footer Links -->
    <div class="container text-center text-md-left mt-5">

      <!-- Grid row -->
      <div class="row mt-3">

        <!-- Grid column -->
        <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">

          <!-- Content -->
          <h6 class="text-uppercase font-weight-bold">Hotel Fern</h6>
          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
          <p>Here you can use rows and columns here to organize your footer content. Lorem ipsum dolor sit amet, consectetur
            adipisicing elit.</p>

        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">

          <!-- Links -->
          <h6 class="text-uppercase font-weight-bold">Products</h6>
          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
          <p>
            <a href="index.php">Hotel Services</a>
          </p>
          <p>
            <a href="form.php">Room Services</a>
          </p>
          <p>
            <a href="restaurant.php">Restaurant</a>
          </p>
          <p>
            <a href="contact.php">Queries</a>
          </p>

        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">

          <!-- Links -->
          <h6 class="text-uppercase font-weight-bold">Useful links</h6>
          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
          <p>
            <a href="index.php">Facilities</a>
          </p>
          <p>
            <a href="form.php">Become a Guest</a>
          </p>
          <p>
            <a href="category.php">Rates</a>
          </p>
          <p>
            <a href="contact.php">Help</a>
          </p>

        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">

          <!-- Links -->
          <h6 class="text-uppercase font-weight-bold">Contact</h6>
          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
         <p>
            <i class="fa fa-home mr-3"></i> JAIPUR ,302022</p>
          <p>
            <i class="fa fa-envelope mr-3"></i> 2017pietcsnikhil073@poornima.org</p>
          <p>
            <i class="fa fa-envelope mr-3"></i> 2017pietcsmridul065@poornima.org</p>
          <p>
            <i class="fa fa-phone mr-3"></i> +91 7665-773-365</p>
          <p>
            <i class="fa fa-print mr-3"></i> +91 7073-910-522</p>

        </div>
        <!-- Grid column -->

      </div>
      <!-- Grid row -->

    </div>
    <!-- Footer Links -->

    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">© 2018 Copyright: MEcrew :)
      
    </div>
    <!-- Copyright -->

  </footer>  <!-- Footer -->
  <!-- /Start your project here-->

  <!-- SCRIPTS -->
  <!-- JQuery -->
  <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.min.js"></script>
</body>

</html>