<?php 
session_start();
 ?>


<!DOCTYPE html>
<html>
<head>

	<title>form page</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
   <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/mdb.min.css" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="css/style.css" rel="stylesheet">
  <style type="text/css">
  	input[type=text],input[type=date], input[type=number], input[type=email]{
  		height: 35px;width: 100%;
  	} 
  </style>
 <script type="text/javascript">
 function checkDate() 
 {
   var selectedText = document.getElementById('form-cout').value;
   var selectedDate = new Date(selectedText);
   var now = new Date();
   if (selectedDate < now)
    {
    alert("Date must be in the future");
   }
 }

  function checkinDate() 
 {
   var selectedText = document.getElementById('form-cin').value;
   var selectedDate = new Date(selectedText);
   var now = new Date();
   if (selectedDate < now)
    {
    alert("Date must be in the future");
   }
 }
function check()
 {
    var username = document.getElementById('form-name').value;
    
      if(username ==""){
        alert("Enter Username");
      return false;
    }
    if((username.length <=2) || (username.length> 30)){
      alert("Enter Username");
      return false;
    }
    if(!isNaN(username)){
      alert("Enter Username");
      return false;
}
}
</script>
</head>
<body>
<div class="container-fluid">
	<div class="well">
		<div class="well" style="width: 40%;margin-left: 30%;box-shadow: 0px 0px 20px;border-radius: 20px;">
		<form action="form1.php" method="post">
			<p><b><h2 align="center">Hotel Room Booking<br></h2></b></p>
			<p align="center">Fill the form regarding room booking query<br></p><hr>

             <div class="md-form">
             <i class="fa fa-user prefix grey-text"></i>
             <input type="text" id="form-name" onchange="check()" class="form-control" name="t1">
             <label for="form-name">Your name</label>
             </div>


		<div class="md-form">
            <i class="fa fa-user prefix grey-text"></i>
            <input type="email" name="t2"  id="form-email" class="form-control" required="">
            <label for="form-email">Email</label>
        </div>

			
		<div class="md-form">
            <i class="fa fa-user prefix grey-text"></i>
            <input type="text" name="t3"  id="form-mob" class="form-control" required="" minlength="10" maxlength="10">
            <label for="form-mob">Mobile NO.</label>
        </div>


			
        <div style="margin-left: 35px;font-size: 18px;color: grey;"><b>Date Of Birth<font style="color: red">*</font></b></div>
		<div class="md-form">
            <i class="fa fa-user prefix grey-text"></i>
            <input type="date" name="t4"  id="form-date" class="form-control" required="" min="1900-01-01" max="2000-12-31">
            <label for="form-mob"></label>
        </div>

			

		<div class="md-form">
            <i class="fa fa-user prefix grey-text"></i>
            <input type="number" name="t5"  id="form-members" class="form-control" required="" min="1" max="4">
            <label for="form-members">Members</label>
        </div>

			
        <div style="margin-left: 35px;font-size: 18px;color: grey;"><b>Check in Date<font style="color: red">*</font></b></div>
		<div class="md-form">
            <i class="fa fa-user prefix grey-text"></i>
            <input type="date" name="t6"  id="form-cin" onchange="checkinDate()" class="form-control" required="">
            <label for="form-cin"></label>
        </div>

			
       <div style="margin-left: 35px;font-size: 18px;color: grey;"><b>Check Out Date<font style="color: red">*</font></b></div>
		<div class="md-form">
            <i class="fa fa-user prefix grey-text"></i>
            <input type="date" name="t7"  id="form-cout" onchange="checkDate()" class="form-control" required="">
            <label for="form-cout"></label>
        </div>

			<div style="margin-left: 35px;font-size: 18px;color: grey;"><b>Room Categories<font style="color: red">*</font></b></div><br>
			<div style="margin-left: 35px;"><select name="t8" required="">
 			<option value="single room">Single Room</option>
  			<option value="double room">Double Room</option>
  			<option value="triple room">Triple Room</option>
  			<option value="studio">Studio</option>
  			<option value="mini suite">Mini Suite</option>
  			<option value="master suite">Master Suite</option>
			</select></div>&nbsp<br><br>
			<div style="margin-left: 35px;font-size: 18px;color: grey;"><b>Resident Proof Document</b><font style="color: red">*</font></div><br>
			<div style="margin-left: 35px;"><input type="file" name="t9" accept="image/*" required=""> &nbsp<br></div>
 			<br><br>
			<center><button class="btn btn-warning" style="height: 50px;width: 140px;border-radius: 10px;"><b><h5>SUBMIT</h5></b></button></center>
		</form>
		</div>
	</div>
	
</div>
</body>
</html>
