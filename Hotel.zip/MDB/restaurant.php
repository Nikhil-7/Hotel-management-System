<?php 
session_start();
 ?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Restaurant</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="css/mdb.min.css" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="css/style.css" rel="stylesheet">
</head>

<body>

  <!-- Start your project here-->
  <nav class="navbar navbar-expand-lg navbar-dark deep-purple">
  <a class="navbar-brand" href="index.php">Hotel Fern</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav"
    aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="gallery.php">Gallery</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="restaurant.php">Restaurant</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="hotelinfo.php">Hotel Info</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="resinfo.php">Restro Info</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="contact.php">Contact Us</a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="form.php">Room Booking</a>
      </li>
      <?php if (!empty($_SESSION["name"])) { ?>
        <li class="nav-item">
        <a class="nav-link" href="category.php">Categories</a>
      </li>
        <li class="nav-item">
        <a class="nav-link" href="resinfo.php"><?php echo $_SESSION["name"];?></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="logout.php">Logout</a>
      </li>
  <?php } 
  else {?>
    
    <li class="nav-item">
      
        <a class="nav-link" href="logsign.php">Log In/Sign Up</a>
      </li>
  <?php } ?>
    </ul>
  </div>
</nav>

<!--Navbar-->

<!-- Card -->
<div class="card card-cascade wider reverse">

  <!-- Card image -->
  <div class="view view-cascade overlay">
    <img class="card-img-top" src="8.jpg" style="height: 800px; width: 100%; margin-top: 2px;" alt="Card image cap">
    <a href="#!">
      <div class="mask rgba-white-slight"></div>
    </a>
  </div>

  <!-- Card content -->
  <div class="card-body card-body-cascade text-center">

    <!-- Title -->
    <h4 class="card-title"><strong>My Restaurant</strong></h4>
    <!-- Subtitle -->
    <h6 class="font-weight-bold indigo-text py-2">Description</h6>
    <!-- Text -->
    <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Exercitationem perspiciatis voluptatum a, quo nobis, non commodi quia repellendus sequi nulla voluptatem dicta reprehenderit, placeat laborum ut beatae ullam suscipit veniam.
    </p>

    <!-- Linkedin -->
    <a class="px-2 fa-lg li-ic"><i class="fa fa-linkedin"></i></a>
    <!-- Twitter -->
    <a class="px-2 fa-lg tw-ic"><i class="fa fa-twitter"></i></a>
    <!-- Dribbble -->
    <a class="px-2 fa-lg fb-ic"><i class="fa fa-facebook"></i></a>

  </div>

</div>
<!-- Card -->

<!-- Section: Products v.2 -->
<section class="text-center my-5">

  <!-- Section heading -->
  <h2 class="h1-responsive font-weight-bold text-center my-5">Our bestsellers</h2>
  <!-- Section description -->
  <p class="grey-text text-center w-responsive mx-auto mb-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fugit, error amet numquam iure provident voluptate esse quasi, veritatis totam voluptas nostrum quisquam eum porro a pariatur veniam.</p>

  <!-- Grid row -->
  <div class="row">

    <!-- Grid column -->
    <div class="col-lg-4 col-md-12 mb-lg-0 mb-4">
      <!-- Card -->
      <div class="card card-cascade wider card-ecommerce">
        <!-- Card image -->
        <div class="view view-cascade overlay">
          <img src="roll.jpg" class="card-img-top" alt="sample photo">
          <a>
            <div class="mask rgba-white-slight"></div>
          </a>
        </div>
        <!-- Card image -->
        <!-- Card content -->
        <div class="card-body card-body-cascade text-center">
          <!-- Category & Title -->
          <a href="" class="text-muted">
            <h5>Dish</h5>
          </a>
          <h4 class="card-title">
            <strong>
              <a href="">Sizzling Veg Spring Rolls.</a>
            </strong>
          </h4>
          <!-- Description -->
          <p class="card-text">Exotic and piping hot dish.</p>
          <!-- Card footer -->
          <div class="card-footer px-1">
            <span class="float-left font-weight-bold">
              <strong>1439$</strong>
            </span>
            <span class="float-right">
              <a class="" data-toggle="tooltip" data-placement="top" title="Quick Look">
                <i class="fa fa-eye grey-text ml-3"></i>
              </a>
              <a class="" data-toggle="tooltip" data-placement="top" title="Add to Wishlist">
                <i class="fa fa-heart grey-text ml-3"></i>
              </a>
            </span>
          </div>
        </div>
        <!-- Card content -->
      </div>
      <!-- Card -->
    </div>
    <!-- Grid column -->

    <!-- Grid column -->
    <div class="col-lg-4 col-md-6 mb-lg-0 mb-4">
      <!-- Card -->
      <div class="card card-cascade wider card-ecommerce">
        <!-- Card image -->
        <div class="view view-cascade overlay">
          <img src="mousse.jpg" class="card-img-top" alt="sample photo">
          <a>
            <div class="mask rgba-white-slight"></div>
          </a>
        </div>
        <!-- Card image -->
        <!-- Card content -->
        <div class="card-body card-body-cascade text-center">
          <!-- Category & Title -->
          <a href="" class="text-muted">
            <h5>Category</h5>
          </a>
          <h4 class="card-title">
            <strong>
              <a href="">Delicious and sweet Mousse.</a>
            </strong>
          </h4>
          <!-- Description -->
          <p class="card-text"> Finger licking good.</p>
          <!-- Card footer -->
          <div class="card-footer px-1">
            <span class="float-left font-weight-bold">
              <strong>1439$</strong>
            </span>
            <span class="float-right">
              <a class="" data-toggle="tooltip" data-placement="top" title="Quick Look">
                <i class="fa fa-eye grey-text ml-3"></i>
              </a>
              <a class="" data-toggle="tooltip" data-placement="top" title="Add to Wishlist">
                <i clq3wAEass="fa fa-heart grey-text ml-3"></i>
              </a>
            </span>
          </div>
        </div>
        <!-- Card content -->
      </div>
      <!-- Card -->
    </div>
    <!-- Grid column -->

    <!-- Grid column -->
    <div class="col-lg-4 col-md-6">
      <!-- Card -->
      <div class="card card-cascade wider card-ecommerce">
        <!-- Card image -->
        <div class="view view-cascade overlay" style="height: 275px;">
          <img src="burger1.jpg" class="card-img-top" alt="sample photo">
          <a>
            <div class="mask rgba-white-slight"></div>
          </a>
        </div>
        <!-- Card image -->
        <!-- Card content -->
        <div class="card-body card-body-cascade text-center">
          <!-- Category & Title -->
          <a href="" class="text-muted">
            <h5>Category</h5>
          </a>
          <h4 class="card-title">
            <strong>
              <a href="">Delicious Burger.</a>
            </strong>
          </h4>
          <!-- Description -->
          <p class="card-text">Mouth watering Burger.</p>
          <!-- Card footer -->
          <div class="card-footer px-1">
            <span class="float-left font-weight-bold">
              <strong>1439$</strong>
            </span>
            <span class="float-right">
              <a class="" data-toggle="tooltip" data-placement="top" title="Quick Look">
                <i class="fa fa-eye grey-text ml-3"></i>
              </a>
              <a class="" data-toggle="tooltip" data-placement="top" title="Add to Wishlist">
                <i class="fa fa-heart grey-text ml-3"></i>
              </a>
            </span>
          </div>
        </div>
        <!-- Card content -->
      </div>
      <!-- Card -->
    </div>
    <!-- Grid column -->

  </div>
  <!-- Grid row -->

</section>
<!-- Section: Products v.2 -->

<!-- Table with panel -->
<div class="card card-cascade narrower">

    <!--Card image-->
    <div class="view view-cascade gradient-card-header blue-gradient narrower py-2 mx-4 mb-3 d-flex justify-content-between align-items-center">

        <div>
            <button type="button" class="btn btn-outline-white btn-rounded btn-sm px-2">
                <i class="fa fa-th-large mt-0"></i>
            </button>
            <button type="button" class="btn btn-outline-white btn-rounded btn-sm px-2">
                <i class="fa fa-columns mt-0"></i>
            </button>
        </div>

        <a href="" class="white-text mx-3">Table name</a>

        <div>
            <button type="button" class="btn btn-outline-white btn-rounded btn-sm px-2">
                <i class="fa fa-pencil mt-0"></i>
            </button>
            <button type="button" class="btn btn-outline-white btn-rounded btn-sm px-2">
                <i class="fa fa-remove mt-0"></i>
            </button>
            <button type="button" class="btn btn-outline-white btn-rounded btn-sm px-2">
                <i class="fa fa-info-circle mt-0"></i>
            </button>
        </div>

    </div>
    <!--/Card image-->

    <div class="px-4">

        <div class="table-wrapper">
            <!--Table-->
            <table class="table table-hover mb-0">

                <!--Table head-->
                <thead>
                    <tr>
                        <th>
                            <input class="form-check-input" type="checkbox" id="checkbox">
                            <label class="form-check-label" for="checkbox" class="mr-2 label-table"></label>
                        </th>
                        <th class="th-lg">
                            <a>Dish No.
                                <i class="fa fa-sort ml-1"></i>
                            </a>
                        </th>
                        <th class="th-lg">
                            <a href="">Dish Name
                                <i class="fa fa-sort ml-1"></i>
                            </a>
                        </th>
                        <th class="th-lg">
                            <a href="">Quantity
                                <i class="fa fa-sort ml-1"></i>
                            </a>
                        </th>
                        <th class="th-lg">
                            <a href="">Code
                                <i class="fa fa-sort ml-1"></i>
                            </a>
                        </th>
                        <th class="th-lg">
                            <a href="">Cost
                                <i class="fa fa-sort ml-1"></i>
                            </a>
                        </th>
                        <th class="th-lg">
                            <a href="">Spices
                                <i class="fa fa-sort ml-1"></i>
                            </a>
                        </th>
                    </tr>
                </thead>
                <!--Table head-->

                <!--Table body-->
                <tbody>
                    <tr>
                        <th scope="row">
                            <input class="form-check-input" type="checkbox" id="checkbox1">
                            <label class="form-check-label" for="checkbox1" class="label-table"></label>
                        </th>
                        <td>Mark</td>
                        <td>Otto</td>
                        <td>@mdo</td>
                        <td>Mark</td>
                        <td>Otto</td>
                        <td>@mdo</td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <input class="form-check-input" type="checkbox" id="checkbox2">
                            <label class="form-check-label" for="checkbox2" class="label-table"></label>
                        </th>
                        <td>Jacob</td>
                        <td>Thornton</td>
                        <td>@fat</td>
                        <td>Jacob</td>
                        <td>Thornton</td>
                        <td>@fat</td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <input class="form-check-input" type="checkbox" id="checkbox3">
                            <label class="form-check-label" for="checkbox3" class="label-table"></label>
                        </th>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <input class="form-check-input" type="checkbox" id="checkbox4">
                            <label class="form-check-label" for="checkbox4" class="label-table"></label>
                        </th>
                        <td>Paul</td>
                        <td>Topolski</td>
                        <td>@P_Topolski</td>
                        <td>Paul</td>
                        <td>Topolski</td>
                        <td>@P_Topolski</td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <input class="form-check-input" type="checkbox" id="checkbox5">
                            <label class="form-check-label" for="checkbox5" class="label-table"></label>
                        </th>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                        <td>Larry</td>
                        <td>the Bird</td>
                        <td>@twitter</td>
                    </tr>
                </tbody>
                <!--Table body-->
            </table>
            <!--Table-->
        </div>

    </div>

</div>
<!-- Table with panel -->

<!-- Footer -->
<footer class="page-footer font-small unique-color-dark">

    <div style="background-color: #6351ce;">
      <div class="container">

        <!-- Grid row-->
        <div class="row py-4 d-flex align-items-center">

          <!-- Grid column -->
          <div class="col-md-6 col-lg-5 text-center text-md-left mb-4 mb-md-0">
            <h6 class="mb-0">Get connected with us on social networks!</h6>
          </div>
          <!-- Grid column -->

          <!-- Grid column -->
          <div class="col-md-6 col-lg-7 text-center text-md-right">

            <a class="fb-ic" href="https://www.facebook.com/">
              <i class="fa fa-facebook white-text mr-4"> </i>
            </a>
            <!-- Twitter -->
            <a class="tw-ic" href="https://www.twitter.com/">
              <i class="fa fa-twitter white-text mr-4"> </i>
            </a>
            <!-- Google +-->
            <a class="gplus-ic" href="https://www.googleplus.com/">
              <i class="fa fa-google-plus white-text mr-4"> </i>
            </a>
            <!--Linkedin -->
            <a class="li-ic" href="https://www.linkedin.com/">
              <i class="fa fa-linkedin white-text mr-4"> </i>
            </a>
            <!--Instagram-->
            <a class="ins-ic" href="https://www.instagram.com/">
              <i class="fa fa-instagram white-text"> </i>
            </a>
          </div>
          <!-- Grid column -->

        </div>
        <!-- Grid row-->

      </div>
    </div>

    <!-- Footer Links -->
    <div class="container text-center text-md-left mt-5">

      <!-- Grid row -->
      <div class="row mt-3">

        <!-- Grid column -->
        <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">

          <!-- Content -->
          <h6 class="text-uppercase font-weight-bold">Hotel Fern</h6>
          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
          <p>Here you can use rows and columns here to organize your footer content. Lorem ipsum dolor sit amet, consectetur
            adipisicing elit.</p>

        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">

          <!-- Links -->
          <h6 class="text-uppercase font-weight-bold">Products</h6>
          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
          <p>
            <a href="index.php">Hotel Services</a>
          </p>
          <p>
            <a href="form.php">Room Services</a>
          </p>
          <p>
            <a href="restaurant.php">Restaurant</a>
          </p>
          <p>
            <a href="contact.php">Queries</a>
          </p>

        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">

          <!-- Links -->
          <h6 class="text-uppercase font-weight-bold">Useful links</h6>
          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
          <p>
            <a href="index.php">Facilities</a>
          </p>
          <p>
            <a href="form.php">Become a Guest</a>
          </p>
          <p>
            <a href="category.php">Rates</a>
          </p>
          <p>
            <a href="contact.php">Help</a>
          </p>

        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">

          <!-- Links -->
          <h6 class="text-uppercase font-weight-bold">Contact</h6>
          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
          <p>
            <i class="fa fa-home mr-3"></i> JAIPUR ,302022</p>
          <p>
            <i class="fa fa-envelope mr-3"></i> 2017pietcsnikhil073@poornima.org</p>
          <p>
            <i class="fa fa-envelope mr-3"></i> 2017pietcsmridul065@poornima.org</p>
          <p>
            <i class="fa fa-phone mr-3"></i> +91 7665-773-365</p>
          <p>
            <i class="fa fa-print mr-3"></i> +91 7073-910-522</p>

        </div>
        <!-- Grid column -->

      </div>
      <!-- Grid row -->

    </div>
    <!-- Footer Links -->

    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">© 2018 Copyright: MEcrew :)
      
    </div>
    <!-- Copyright -->

  </footer>  <!-- Footer -->
  <!-- /Start your project here-->

  <!-- SCRIPTS -->
  <!-- JQuery -->
  <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.min.js"></script>
</body>

</html>