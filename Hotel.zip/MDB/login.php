<?php
session_start(); 
$a=$_POST['lemail'];
$b=$_POST['lpass'];

$server='localhost';
$username='root';
$password='';
$dbname='hotel';

$connect= mysqli_connect($server,$username,$password,$dbname);
if($connect)
{
	$sql0="SELECT * FROM `user` WHERE email='$a' && password='$b'";
	
	if(mysqli_query($connect,$sql0))
		{
			$result1=mysqli_query($connect,$sql0);

			if(mysqli_num_rows($result1)>0)
				{
					if($row=mysqli_fetch_assoc($result1))
						{
							$_SESSION["name"]=$row["name"];
							$_SESSION["type"]=$row["type"];
							$_SESSION["email"]=$b;
							echo "<script>window.location.assign('index.php')</script>";
 						}
 				}
 				else {
 						echo "<script>alert('invalid username and password
 						....');window.location.assign('index.php')</script>";
 					}	
 		}	

} 				?>	