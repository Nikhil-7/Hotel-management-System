<!DOCTYPE html>
<html>
<head>
	<title>form page</title>
	<link href="css1/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="css1/mdb.min.css" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="css1/style.css" rel="stylesheet">
  <style type="text/css">
  	input[type=text],input[type=date], input[type=number], input[type=email]{
  		height: 35px;width: 100%;
  	} 
  </style>
</head>
<body>
<div class="container-fluid">
	<div class="well">
		<div class="well" style="width: 40%;margin-left: 30%;box-shadow: 0px 0px 20px;border-radius: 20px;">
		<form>
			<p><b><h2 align="center">Hotel Room Booking<br></h2></b></p>
			<p align="center">Fill the form regarding room booking query<br></p><hr>
			Name&nbsp <br><input type="text" name="t1" placeholder="name" required=""><br><br>
			Email<br><input type="email" name="t3" placeholder="eg. example@gmail.com" required=""><br><br>
			Mobile No.<br><input type="text" name="t4" placeholder="eg. 0678348342" required="" minlength="10" maxlength="10"><br><br>
			Birth Date <br><input type="date" name="t5" placeholder="" required="" min="1900-01-01" max="2000-12-31"><br><br>
			Members <br><input type="number" name="t6" placeholder="" required="" min="1" max="4"><br><br>
			CheckIn Date<br><input type="date" name="t7" required="" placeholder=""><br><br>
			CheckOut Date<br><input type="date" name="t8" required="" placeholder=""><br><br>
			Room Category<br><select name="type" required="">
			<option value="fiat" selected>None</option>
 			<option value="single">Single Room</option>
  			<option value="double">Double Room</option>
  			<option value="triple">Triple Room</option>
  			<option value="studio">Studio</option>
  			<option value="mini">Mini Suite</option>
  			<option value="master">Master Suite</option>
			</select>&nbsp<br><br>
			<input type="file" name="pic" accept="image/*">
 			<input type="submit" required="">&nbsp<br>
 			<br><br>
			<center><button class="btn btn-warning" style="height: 50px;width: 140px;border-radius: 10px;"><b><h5>SUBMIT</h5></b></button></center>
		</form>
		</div>
	</div>
	
</div>
</body>
</html>
